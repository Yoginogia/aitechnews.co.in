# 🤖 AITechNews - AI Auto Article Agent

Roz subah 7 AM IST pe automatically latest tech news dhundh ke
Hindi+English articles likhta hai aur website pe publish karta hai.

---

## 🏗️ Architecture

```
Internet (RSS Feeds)
    ↓
GitHub Actions (7 AM daily)
    ↓
news_agent.py runs
    ↓
Claude AI articles likhta hai (3 articles/day)
    ↓
articles/*.json save hote hain
    ↓
Git push → Vercel auto-deploy
    ↓
Website live update! 🎉
```

---

## ⚡ Setup (Sirf ek baar)

### Step 1: Files apni repo mein daalo

Ye files apni Next.js repo mein copy karo:

```
your-repo/
├── .github/
│   └── workflows/
│       └── daily_articles.yml   ← GitHub Actions
├── scripts/
│   └── news_agent.py            ← Main agent
├── lib/
│   └── articles.js              ← Next.js helper
└── articles/                    ← Auto-generate hoga
    ├── index.json
    └── [slug].json
```

### Step 2: Claude API Key lo

1. https://console.anthropic.com pe jao
2. Account banao (free credits milte hain)
3. API Keys → Create Key → Copy karo

### Step 3: GitHub Secret set karo

1. GitHub repo → Settings → Secrets and variables → Actions
2. "New repository secret" click karo
3. Name: `CLAUDE_API_KEY`
4. Value: apna Claude API key paste karo
5. Save ✅

### Step 4: GitHub Actions enable karo

1. Repo → Actions tab
2. "I understand my workflows" → Enable

### Step 5: Test run karo

1. Actions → "AITechNews Daily Article Writer"
2. "Run workflow" → articles_count: 1 → Run
3. 2-3 minute wait karo
4. `articles/` folder mein new JSON dekho ✅

---

## 📰 Kaise Kaam Karta Hai

### 1. News Fetch (RSS Feeds — FREE)
- TechCrunch AI section
- The Verge AI
- NDTV Gadgets
- 91Mobiles
- GSMArena
- Gadgets360
- CoinTelegraph
- 7+ aur sources

### 2. Topic Selection (Claude AI)
Indian readers ke liye best 3 topics automatically choose karta hai:
- 5G news → priority
- Phone launches → priority  
- AI tools → priority
- Price changes → priority

### 3. Article Generation (Claude Sonnet)
Har article mein:
- Catchy Hinglish title
- 600-800 words detailed content
- India-specific impact section
- SEO meta tags
- Proper HTML formatting

### 4. Auto Publish (GitHub → Vercel)
- `articles/index.json` update hota hai
- Git push → Vercel build trigger
- 1-2 minute mein site live!

---

## 📁 Article JSON Format

```json
{
  "slug": "chatgpt-new-feature-hindi-2026",
  "title": "ChatGPT का नया Feature: अब हिंदी में सोचता है AI!",
  "category": "AI Tools",
  "date": "2026-04-12",
  "readTime": "4 min read",
  "excerpt": "OpenAI ne ChatGPT mein ek bada update diya...",
  "content": "<h2>Kya hai naya?</h2><p>...</p>",
  "tags": ["ChatGPT", "AI", "Hindi", "OpenAI"],
  "metaTitle": "ChatGPT Hindi Feature Update 2026",
  "metaDescription": "ChatGPT ab Hindi mein...",
  "image": "/images/blog/chatgpt-hindi.jpg",
  "source": "TechCrunch",
  "sourceUrl": "https://techcrunch.com/..."
}
```

---

## 🔧 Customize Karo

### Aur RSS feeds add karo (`news_agent.py` line 25):
```python
{"url": "https://yoursource.com/feed", "category": "AI Tools"},
```

### Articles count change karo:
```python
MAX_ARTICLES = 5  # 3 se 5 karo
```

### Schedule change karo (`.github/workflows/daily_articles.yml`):
```yaml
# Subah 7 AM aur Shaam 7 PM dono
- cron: '30 1 * * *'   # 7 AM IST
- cron: '30 13 * * *'  # 7 PM IST
```

---

## 💰 Cost

| Service | Cost |
|---------|------|
| GitHub Actions | ✅ FREE (2000 min/month) |
| RSS Feeds | ✅ FREE |
| Claude API | ~$0.05-0.10 per run (3 articles) |
| **Total/month** | **~₹100-150/month** |

---

## ❓ Troubleshooting

**Agent fail ho gaya?**
→ GitHub → Actions → Failed run → Logs check karo

**Articles publish nahi ho rahe?**
→ `articles/index.json` ko website ka code read kar raha hai? Check karo

**API quota khatam?**
→ Anthropic Console pe usage dekho

---

## 📞 Support

Website: https://aitechnews.co.in
